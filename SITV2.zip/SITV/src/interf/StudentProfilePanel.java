package interf;

import SitvClasses.Main;
import interf.TryInterf;
import interf.Entry;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jmf.videoplayer.JMFVideoPlayer;

@SuppressWarnings("serial")
public class StudentProfilePanel extends JPanel {

	/*private Font myFont = new Font("SanSerif", Font.BOLD, 20);
	JTabbedPane studentProfile = new JTabbedPane();
	private JLabel fio = new JLabel("Full Name:");
        private JTextField fioField = new JTextField(Entry.student1.fio);
	private JLabel email = new JLabel("e-mail:");
        private JTextField emailField = new JTextField(Entry.student1.email);
	private JLabel login = new JLabel("Login:");
        private JTextField loginField = new JTextField(Entry.student1.login);
	private JLabel password = new JLabel("Password:");
        private JTextField passwordField = new JTextField(Entry.student1.password);
	private JLabel dateOfBirth = new JLabel("Date of Birth:");
        private JTextField dateOfBirthField = new JTextField(Entry.student1.birthdayDate);
	private JLabel group = new JLabel("Group:");
        private JTextField groupField = new JTextField(Entry.student1.group);
	private JLabel question = new JLabel("Secret Question:");
        private JTextField questionField = new JTextField(Entry.student1.secretQuestion);
	private JLabel answer = new JLabel("Answer:");
        private JTextField answerField = new JTextField(Entry.student1.secretAnswer);
	protected JButton delete = new JButton("Delete your account");
	protected JButton edit = new JButton("Edit profile");
        protected JButton watch = new JButton("Watch video");
	JPanel panel1 = new JPanel();
	JPanel panel2 = new JPanel();
        private int N = 0;
	
	private TryInterf window;
	
	public StudentProfilePanel(TryInterf frame) {
		
		window = frame;
		setLayout(null);
		setFocusable(true);
		grabFocus();
		
		panel1.setLayout(null);
		panel2.setLayout(null);
		
		studentProfile.setBounds(0, 0, 800, 600);
		studentProfile.addTab("Personal Inforamation", null, panel1, "Click here to see the information about you");
		studentProfile.addTab("Your marks", null, panel2, "Click here to see your marks");
		add(studentProfile);
		
		fio.setBounds(45, 0, 350, 50);
		fio.setFont(myFont);
		panel1.add(fio);
                
              fioField.setBounds(45, 50, 350, 50);
		fioField.setFont(myFont);
               // fioField.setText(Entry.student1.fio);
		fioField.setEditable(false);
		panel1.add(fioField);

		email.setBounds(45, 100, 350, 50);
		email.setFont(myFont);
		panel1.add(email);
                emailField.setBounds(45, 150, 350, 50);
		emailField.setFont(myFont);
		emailField.setEditable(false);
		panel1.add(emailField);
		
		login.setBounds(45, 200, 350, 50);
		login.setFont(myFont);
		panel1.add(login);
                loginField.setBounds(45, 250, 350, 50);
		loginField.setFont(myFont);
		loginField.setEditable(false);
		panel1.add(loginField);
		
		password.setBounds(45, 300, 350, 50);
		password.setFont(myFont);
		panel1.add(password);
		passwordField.setBounds(45, 350, 350, 50);
		passwordField.setFont(myFont);
		passwordField.setEditable(false);
		panel1.add(passwordField);
		dateOfBirth.setBounds(445, 0, 350, 50);
		dateOfBirth.setFont(myFont);
		panel1.add(dateOfBirth);
                dateOfBirthField.setBounds(445, 50, 350, 50);
		dateOfBirthField.setFont(myFont);
		//dateOfBirthField.setValue(new Date());
		dateOfBirthField.setEditable(false);
		panel1.add(dateOfBirthField);

		
		group.setBounds(445, 100, 350, 50);
		group.setFont(myFont);
		panel1.add(group);
                groupField.setBounds(445, 150, 350, 50);
		groupField.setFont(myFont);
		groupField.setEditable(false);
		panel1.add(groupField);
		
		question.setBounds(445, 200, 350, 50);
		question.setFont(myFont);
		panel1.add(question);
                questionField.setBounds(445, 250, 350, 50);
		questionField.setFont(myFont);
		questionField.setEditable(false);
		panel1.add(questionField);
		
		answer.setBounds(445, 300, 350, 50);
		answer.setFont(myFont);
		panel1.add(answer);
                answerField.setBounds(445, 350, 350, 50);
		answerField.setFont(myFont);
		answerField.setEditable(false);
		panel1.add(answerField);
                
               watch.setBounds(45,430, 350, 50);
		watch.setFont(myFont);
		panel2.add(watch);
		
		delete.setBounds(530, 430, 250, 50);
		delete.setFont(myFont);
		panel1.add(delete);
                
                ActionListener actionWatch = (ActionEvent e) -> {
			setVisible(false);
			window.VisiblePanel();
                            JMFVideoPlayer.begin();
		};
		watch.addActionListener(actionWatch);
		
		ActionListener actionDelete = (ActionEvent e) -> {
			setVisible(false);
			window.VisiblePanel();
                        Main.userMap.remove(Entry.student1.login, Entry.student1.getPersonalInf());    
		};
		delete.addActionListener(actionDelete);
		
		edit.setBounds(45,430, 350, 50);
		edit.setFont(myFont);
		panel1.add(edit);
                ActionListener actionEdit = (ActionEvent e) -> {
                    ++N;
                    if (N%2==1){
			//setVisible(true);
			//window.VisiblePanel();
                        answerField.setEditable(true);
                        questionField.setEditable(true);
                        groupField.setEditable(true);
                        dateOfBirthField.setEditable(true);
                        fioField.setEditable(true);
                        loginField.setEditable(true);
                        passwordField.setEditable(true);
                        emailField.setEditable(true);
                    }
                    else{
                       // setVisible(true);
			//window.VisiblePanel();
                        answerField.setEditable(false);
                        questionField.setEditable(false);
                        groupField.setEditable(false);
                        dateOfBirthField.setEditable(false);
                        fioField.setEditable(false);
                        loginField.setEditable(false);
                        passwordField.setEditable(false);
                        emailField.setEditable(false);
                        ArrayList <String> info = new ArrayList<>();
                        info.add(loginField.getText());
                        info.add(passwordField.getText());
                        info.add(questionField.getText());
                        info.add(answerField.getText());
                        info.add(dateOfBirthField.getText());
                        info.add(fioField.getText());
                        info.add(emailField.getText());
                        info.add(groupField.getText());
                        Entry.student1.editPersonalInf(info);
                        Main.userMap.put(Entry.student1.login, Entry.student1.getPersonalInf() );
                    }
		};
		edit.addActionListener(actionEdit);
	}*/
        
	
}
