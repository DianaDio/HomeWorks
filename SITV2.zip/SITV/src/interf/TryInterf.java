package interf;

import interf.Entry;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;


public class TryInterf {

	private JFrame window = new JFrame("Entry"); 
	
	public TryInterf() {
		
		SetPanel(new Entry(this), "Entry", 440, 520);
		
	}
	
	public void SetPanel (JPanel panel, String name, int width, int height) {
		//window.setVisible(false);
		window = new JFrame(name);
		window.setSize(width, height);
		window.add(panel);
		window.setLocationRelativeTo(null);
		window.setResizable(false);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
	}
	
	public void VisiblePanel() {
		window.setVisible(false);
	}
	
	/*public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override 
			public void run() {
                            TryInterf tryInterf = new TryInterf();
			}
		});
	}*/
}
