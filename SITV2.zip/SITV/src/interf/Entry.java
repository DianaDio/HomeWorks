package interf;

import SitvClasses.Main;
//import SitvClasses.Registry;
import SitvClasses.Student;
import java.awt.BorderLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JDialog;

@SuppressWarnings("serial")
public class Entry extends JPanel {

	private Font myFont = new Font("SanSerif", Font.BOLD, 20);
        private Font smallFont = new Font("SanSerif", Font.HANGING_BASELINE, 10);
	private JTextField loginField = new JTextField();
	private JLabel login = new JLabel("Login:");
        private JLabel wrongLogin = new JLabel("");
	private JTextField passwordField = new JTextField();
	private JLabel password = new JLabel("Password:");
        private JLabel wrongPassword = new JLabel("");
	private JButton registration = new JButton("Registration");
	private JButton entry = new JButton("Entry");
	//private JRadioButton student = new JRadioButton("Student");
	//private JRadioButton admin = new JRadioButton("Administrator");
	private TryInterf window;
        private int N = 0;
       // private AboutDialog dialog;
	public static Student student1; 
	public Entry(TryInterf frame) {
		
		window = frame;
		setLayout(null);
		setFocusable(true);
		grabFocus();
		
		//ButtonGroup users = new ButtonGroup();
		//users.add(student);
		//users.add(admin);
		
		//student.setBounds(20, 270, 100, 50);
		//student.setFont(myFont);
		//add(student);
		//admin.setBounds(20, 320, 200, 50);
		//admin.setFont(myFont);
		//add(admin);
		
		registration.setBounds(10, 400, 200, 50);
		registration.setFont(myFont);
		add(registration);
		
		entry.setBounds(220, 400, 200, 50);
		entry.setFont(myFont);
		add(entry);
		
		loginField.setBounds(120, 100, 300, 50);
		loginField.setFont(myFont);
		loginField.setEditable(true);
		add(loginField);
                
                wrongLogin.setBounds(120,130,300,50);
                 wrongLogin.setFont(smallFont);
                  add( wrongLogin);
		
		passwordField.setBounds(120, 200, 300, 50);
		passwordField.setFont(myFont);
		passwordField.setEditable(true);
		add(passwordField);
                
                wrongPassword.setBounds(120,230,300,50);
                 wrongPassword.setFont(smallFont);
                  add( wrongPassword);
		
		login.setBounds(50, 100, 100, 50);
		login.setFont(myFont);
		add(login);
		
		password.setBounds(10, 200, 100, 50);
		password.setFont(myFont);
		add(password);
		 
		//ActionListener actionEntry;
                 
            /*actionEntry = (ActionEvent e) -> {
               
                if (!Main.userMap.containsKey(loginField.getText())){
                    wrongLogin.setText( "There is no user with this login");
                }
                else{++N;
                     
                        if (!Main.userMap.get(loginField.getText()).get(0).equals(passwordField.getText())){
                            wrongPassword.setText("Wrong password");
                        }
                        
                        else if (N<=5 && (!loginField.getText().equals(Main.admin1.login))){
                             student1 =  new Student(loginField.getText(),  Main.userMap.get(loginField.getText()));
                             window.SetPanel(new StudentProfilePanel(window), "Student Profile", 800, 550);
                        }
                        else if (loginField.getText().equals(Main.admin1.login)){
                            window.SetPanel(new AdminProfilePanel(window), "Administrator Profile", 800, 550);
                        }
                        else if(N>5 && (!loginField.getText().equals(Main.admin1.login))&& (!Main.userMap.get(loginField.getText()).get(0).equals(passwordField.getText()))) {
                        student1 =  new Student(loginField.getText(),  Main.userMap.get(loginField.getText()));
                    student1.blockStatus = true;
                         Main.userMap.put(student1.login, student1.getPersonalInf() );
                          
                        passwordField.setEditable(false);
                        				 
                                 java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SecretQuestion dialog = new SecretQuestion(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
                        }
                        
                }*/
                
                    
                
              /* if ((!loginField.getText().equals(Main.admin1.login))&&(Main.userMap.containsKey(loginField.getText()))&&(Main.userMap.get(loginField.getText()).get(0).equals(passwordField.getText()))){
                    window.SetPanel(new StudentProfilePanel(window), "Student Profile", 800, 550);
                } else if ((loginField.getText().equals(Main.admin1.login))&&(Main.userMap.containsKey(loginField.getText()))&&(Main.userMap.get(loginField.getText()).get(0).equals(passwordField.getText())))
                    window.SetPanel(new AdminProfilePanel(window), "Administrator Profile", 800, 550);*/
           // };
		//entry.addActionListener(actionEntry);
		
	/*ActionListener actionRegistry = (ActionEvent e) -> {
            setVisible(false);
			window.VisiblePanel();
			window.SetPanel(new Registry(window), "Registration", 840, 550);
		};
		registration.addActionListener(actionRegistry);
	
        ActionListener actionEntry = (ActionEvent e) -> {
            if (Main.userMap.containsKey(loginField.getText())&&(loginField.getText().equals(Main.admin1.login))&&(Main.userMap.get(loginField.getText()).get(0).equals(passwordField.getText()))){
            wrongLogin.setText( "");
             wrongPassword.setText( "");
             setVisible(false);
			window.VisiblePanel();
                            window.SetPanel(new AdminProfilePanel(window), "Administrator Profile", 800, 550);
            }
            else if (Main.userMap.containsKey(loginField.getText())&&(loginField.getText().equals(Main.admin1.login))&&(!Main.userMap.get(loginField.getText()).get(0).equals(passwordField.getText()))){
             wrongPassword.setText("Wrong password");
            }
            else if (Main.userMap.containsKey(loginField.getText())&&(!loginField.getText().equals(Main.admin1.login))){
                wrongLogin.setText( "");
                if (Main.userMap.get(loginField.getText()).get(0).equals(passwordField.getText())&&(Main.userMap.get(loginField.getText()).get(8).equals("false"))){
                 wrongPassword.setText( "");
                 student1 =  new Student(loginField.getText(),  Main.userMap.get(loginField.getText()));
                            setVisible(false);
			window.VisiblePanel();
                             window.SetPanel(new StudentProfilePanel(window), "Student Profile", 800, 550);
                }
                else if(Main.userMap.get(loginField.getText()).get(8).equals("true")){
                    java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SecretQuestion dialog = new SecretQuestion(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
                }
                else if (Main.userMap.get(loginField.getText()).get(8).equals("false")&&(!Main.userMap.get(loginField.getText()).get(0).equals(passwordField.getText()))){
                 ++N;
                                    wrongPassword.setText("Wrong password");
                                    if (N>5){
                               setVisible(false);
			window.VisiblePanel();
                               student1 =  new Student(loginField.getText(),  Main.userMap.get(loginField.getText()));
                    student1.blockStatus = true;
                         Main.userMap.put(student1.login, student1.getPersonalInf() );
                                               java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SecretQuestion dialog = new SecretQuestion(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
                                    }
                
                }
                }
             else if (!Main.userMap.containsKey(loginField.getText())){
                  wrongLogin.setText( "There is no user with this login");
             }
                 
           
		};
		entry.addActionListener(actionEntry);*/
	}
        }

  
     
