package SitvClasses;

import java.util.Date;

public class VideoFile {

    protected
        String fileName;
        //VideoQuestionBase question;
        boolean open;
        // Date queue of stopPoints

    // Here must be Constructor

    protected void getVideoDetails(){

    }

    protected void pause(){

    }

    protected void stop(){

    }

    protected void play(){

    }

    protected void sortStopPoints(){

    }
}
