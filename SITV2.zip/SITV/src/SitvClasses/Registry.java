package interf;

import SitvClasses.Main;
import SitvClasses.Student;
import interf.Entry;
import interf.TryInterf;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

@SuppressWarnings("serial")
public class Registry extends JPanel {

	private Font myFont = new Font("SanSerif", Font.HANGING_BASELINE, 20);
        private Font smallFont = new Font("SanSerif", Font.HANGING_BASELINE, 10);
	private JButton registry = new JButton("Sign-Up");
        private JButton exit = new JButton("Exit");
	private JLabel fio = new JLabel("Full Name:");
	private JTextField fioField = new JTextField();
	private JLabel email = new JLabel("e-mail:");
	private JTextField emailField = new JTextField();
	private JLabel login = new JLabel("Login:");
	private JTextField loginField = new JTextField();
        private JLabel wrongLogin = new JLabel("");
	private JLabel password = new JLabel("Password:");
	private JTextField passwordField = new JTextField();
         private JLabel wrongPassword = new JLabel("");
	private DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
	private JLabel dateOfBirth = new JLabel("Date of Birth:");
	private JFormattedTextField dateOfBirthField = new JFormattedTextField(df);
	private JLabel group = new JLabel("Group:");
	private JTextField groupField = new JTextField();
	 private JLabel wrongInfo = new JLabel("");
	
	String[] questions = {"Maiden name", "Pet name", "The name of your best friend"};
	JComboBox choice = new JComboBox(questions);
	private JTextField answerField = new JTextField();
	private JLabel question = new JLabel("Secret Question:");
	private JLabel answer = new JLabel("Answer:");
	private TryInterf window;
	
	public Registry(TryInterf frame) {
		
		window = frame;
		setLayout(null);
		setFocusable(true);
		grabFocus();
		
		fio.setBounds(45, 0, 350, 50);
		fio.setFont(myFont);
		add(fio);
		
		fioField.setBounds(45, 50, 350, 50);
		fioField.setFont(myFont);
		fioField.setEditable(true);
		add(fioField);
		
		email.setBounds(45, 100, 350, 50);
		email.setFont(myFont);
		add(email);
		
		emailField.setBounds(45, 150, 350, 50);
		emailField.setFont(myFont);
		emailField.setEditable(true);
		add(emailField);
		
		login.setBounds(45, 200, 350, 50);
		login.setFont(myFont);
		add(login);
		
		loginField.setBounds(45, 250, 350, 50);
		loginField.setFont(myFont);
		loginField.setEditable(true);
		add(loginField);
                 
               // loginField.getText();
		
		password.setBounds(45, 300, 350, 50);
		password.setFont(myFont);
		add(password);
                
		
		passwordField.setBounds(45, 350, 350, 50);
		passwordField.setFont(myFont);
		passwordField.setEditable(true);
		add(passwordField);
                 
		
		dateOfBirth.setBounds(445, 0, 350, 50);
		dateOfBirth.setFont(myFont);
		add(dateOfBirth);
		
		dateOfBirthField.setBounds(445, 50, 350, 50);
		dateOfBirthField.setFont(myFont);
		dateOfBirthField.setValue(new Date());
		dateOfBirthField.setEditable(true);
		add(dateOfBirthField);
		
		group.setBounds(445, 100, 350, 50);
		group.setFont(myFont);
		add(group);
		
		groupField.setBounds(445, 150, 350, 50);
		groupField.setFont(myFont);
		groupField.setEditable(true);
		add(groupField);
		
		question.setBounds(445, 200, 350, 50);
		question.setFont(myFont);
		add(question);
		
		choice.setBounds(445, 250, 350, 50);
		choice.setFont(myFont);
		add(choice);
		
		answer.setBounds(445, 300, 350, 50);
		answer.setFont(myFont);
		add(answer);
		
		answerField.setBounds(445, 350, 350, 50);
		answerField.setFont(myFont);
		answerField.setEditable(true);
		add(answerField);
		
		registry.setBounds(320, 430, 200, 50);
		registry.setFont(myFont);
		add(registry);
                
                exit.setBounds(445, 430, 350, 50);
		exit.setFont(myFont);
		add(exit);
                
                wrongPassword.setBounds(45, 380, 350, 50);
		wrongPassword.setFont(smallFont);
		 
		add(wrongPassword);
                 wrongLogin.setBounds(45, 280, 350, 50);
		wrongLogin.setFont(smallFont);
		 
		add(wrongLogin);
		
                wrongInfo.setBounds(550, 430, 350, 50);
                wrongInfo.setFont(smallFont);
                add(wrongInfo);
                
                 ActionListener actionExit = (ActionEvent e) -> {
                     setVisible(false);
                     window.VisiblePanel(); 
            window.SetPanel(new Entry(window), "Entry", 440, 520);
                     };
		exit.addActionListener(actionExit);
                 
                    
		ActionListener actionSingUp = (ActionEvent e) -> {
                    
                
                   
                   if (!"".equals(Main.checkPassword(passwordField.getText()))||!"".equals(Main.checkLogin(loginField.getText()))){
                       wrongPassword.setText(Main.checkPassword(passwordField.getText()));
                    wrongLogin.setText(Main.checkLogin(loginField.getText())); 
                   }
                   else if (!"".equals(Main.checkInfo(emailField.getText()))){
                       wrongInfo.setText(Main.checkInfo(emailField.getText()));
                   }
                   else if (!"".equals(Main.checkInfo(answerField.getText()))){
                        wrongInfo.setText(Main.checkInfo(answerField.getText()));
                   }
                   else if (!"".equals(Main.checkInfo(groupField.getText()))){
                       wrongInfo.setText(Main.checkInfo(groupField.getText()));
                   }
                   else if (!"".equals(Main.checkInfo(fioField.getText()))){
                       wrongInfo.setText(Main.checkInfo(fioField.getText()));
                   }
                   else if ( !"".equals(Main.checkInfo(dateOfBirthField.getText()))){
                   wrongInfo.setText(Main.checkInfo(dateOfBirthField.getText()));
                    
                }
                     
                     
                    else{
                         //String name = loginField.getText();
                       // System.out.println(Main.userMap);
                       ArrayList <String> info = new ArrayList<>();
                       // info.add(loginField.getText());
                        info.add(passwordField.getText());
                        info.add((String)choice.getSelectedItem());
                        info.add(answerField.getText());
                        info.add(dateOfBirthField.getText());
                        info.add(fioField.getText());
                        info.add(emailField.getText());
                        info.add(groupField.getText());
                        info.add("0");
                        info.add("false");
                         Student student = new Student(loginField.getText(), info);
                       Main.userMap.put(student.login, student.getPersonalInf() );
			setVisible(false);
			window.VisiblePanel(); 
                   window.SetPanel(new Entry(window), "Entry", 440, 520);}
		};
		registry.addActionListener(actionSingUp);
                 
	}
	
}
