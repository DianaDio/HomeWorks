package interf;

import SitvClasses.HelpUsers;
import SitvClasses.Main;
import interf.TryInterf;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class AdminProfilePanel extends JPanel{
/*
	//JTabbedPane adminProfile = studentProfile;
	JPanel tabManagment = new JPanel();
        private Font myFont = new Font("SanSerif", Font.BOLD, 20);
	JTabbedPane adminProfile = new JTabbedPane();
	private JLabel fio = new JLabel("Full Name:");
        private JTextField fioField = new JTextField(Main.admin1.fio);
	private JLabel email = new JLabel("e-mail:");
        private JTextField emailField = new JTextField(Main.admin1.email);
	private JLabel login = new JLabel("Login:");
        private JTextField loginField = new JTextField(Main.admin1.login);
	private JLabel password = new JLabel("Password:");
        private JTextField passwordField = new JTextField(Main.admin1.password);
	private JLabel dateOfBirth = new JLabel("Date of Birth:");
        private JTextField dateOfBirthField = new JTextField(Main.admin1.birthdayDate);
	//private JLabel group = new JLabel("Group:");
        //private JTextField groupField = new JTextField(Entry.student1.group);
	private JLabel question = new JLabel("Secret Question:");
        private JTextField questionField = new JTextField(Main.admin1.secretQuestion);
	private JLabel answer = new JLabel("Answer:");
        private JTextField answerField = new JTextField(Main.admin1.secretAnswer);
	//protected JButton delete = new JButton("Delete your account");
	protected JButton edit = new JButton("Edit profile");
        protected JButton help = new JButton("Users have problems");
	JPanel panel1 = new JPanel();
	JPanel panel2 = new JPanel();
        private int N = 0;
	
	private TryInterf window;
	
	public AdminProfilePanel(TryInterf frame) {
            
            window = frame;
		setLayout(null);
		setFocusable(true);
		grabFocus();
		
		panel1.setLayout(null);
		panel2.setLayout(null);
		
		adminProfile.setBounds(0, 0, 800, 600);
		adminProfile.addTab("Personal Inforamation", null, panel1, "Click here to see the information about you");
		adminProfile.addTab("User managment", null, tabManagment, "Click here to control user's accounts");
		add(adminProfile);
		
		fio.setBounds(45, 0, 350, 50);
		fio.setFont(myFont);
		panel1.add(fio);
                
              fioField.setBounds(45, 50, 350, 50);
		fioField.setFont(myFont);
               // fioField.setText(Entry.student1.fio);
		fioField.setEditable(false);
		panel1.add(fioField);

		email.setBounds(45, 100, 350, 50);
		email.setFont(myFont);
		panel1.add(email);
                emailField.setBounds(45, 150, 350, 50);
		emailField.setFont(myFont);
		emailField.setEditable(false);
		panel1.add(emailField);
		
		login.setBounds(45, 200, 350, 50);
		login.setFont(myFont);
		panel1.add(login);
                loginField.setBounds(45, 250, 350, 50);
		loginField.setFont(myFont);
		loginField.setEditable(false);
		panel1.add(loginField);
		
		password.setBounds(45, 300, 350, 50);
		password.setFont(myFont);
		panel1.add(password);
		passwordField.setBounds(45, 350, 350, 50);
		passwordField.setFont(myFont);
		passwordField.setEditable(false);
		panel1.add(passwordField);
		dateOfBirth.setBounds(445, 0, 350, 50);
		dateOfBirth.setFont(myFont);
		panel1.add(dateOfBirth);
                dateOfBirthField.setBounds(445, 50, 350, 50);
		dateOfBirthField.setFont(myFont);
		//dateOfBirthField.setValue(new Date());
		dateOfBirthField.setEditable(false);
		panel1.add(dateOfBirthField);

		
		 
		
		question.setBounds(445, 100, 350, 50);
		question.setFont(myFont);
		panel1.add(question);
                questionField.setBounds(445, 150, 350, 50);
		questionField.setFont(myFont);
		questionField.setEditable(false);
		panel1.add(questionField);
		
		answer.setBounds(445, 200, 350, 50);
		answer.setFont(myFont);
		panel1.add(answer);
                answerField.setBounds(445, 250, 350, 50);
		answerField.setFont(myFont);
		answerField.setEditable(false);
		panel1.add(answerField);
		
		 
		
		 
		
		edit.setBounds(530, 430, 250, 50);
		edit.setFont(myFont);
		panel1.add(edit);
                
                help.setBounds(530, 430, 250, 50);
                
		help.setFont(myFont);
		panel2.add(help);
                
                 ActionListener actionHelp = (ActionEvent e) -> {
                     setVisible(false);
                      java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HelpUsers().setVisible(true);
            }
        });
                     //window.VisiblePanel(); 
           // window.SetPanel(new Entry(window), "Entry", 440, 520);
                     };
		help.addActionListener(actionHelp);
                
                ActionListener actionEdit = (ActionEvent e) -> {
                    ++N;
                    if (N%2==1){
			//setVisible(true);
			//window.VisiblePanel();
                        answerField.setEditable(true);
                        questionField.setEditable(true);
                        //groupField.setEditable(true);
                        dateOfBirthField.setEditable(true);
                        fioField.setEditable(true);
                        loginField.setEditable(true);
                        passwordField.setEditable(true);
                        emailField.setEditable(true);
                    }
                    else{
                       // setVisible(true);
			//window.VisiblePanel();
                        answerField.setEditable(false);
                        questionField.setEditable(false);
                        //groupField.setEditable(false);
                        dateOfBirthField.setEditable(false);
                        fioField.setEditable(false);
                        loginField.setEditable(false);
                        passwordField.setEditable(false);
                        emailField.setEditable(false);
                        ArrayList <String> info = new ArrayList<>();
                        info.add(loginField.getText());
                        info.add(passwordField.getText());
                        info.add(questionField.getText());
                        info.add(answerField.getText());
                        info.add(dateOfBirthField.getText());
                        info.add(fioField.getText());
                        info.add(emailField.getText());
                        //info.add(groupField.getText());
                        Main.admin1.editPersonalInf(info);
                        Main.userMap.put(Main.admin1.login, Main.admin1.getPersonalInf() );
                    }
		};
		edit.addActionListener(actionEdit);
	}
            
            */
            
            

		 
	
	}
	
	

