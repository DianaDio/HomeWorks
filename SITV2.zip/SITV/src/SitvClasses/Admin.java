/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SitvClasses;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Марина
 */
public class Admin extends User {

    public Admin(String login, List<String> info) {
        super(login, info);
        super.role = "1";
    }
    
    // Here must be Constructor

/*    protected void setRole(){

    }*/

    protected void blockUser(User Vasya){
    Vasya.blockStatus = true;
    }

    protected void setBlockReason(){

    }

    protected void returnAccess(User Vasya){
Vasya.blockStatus = false;
    }

    protected void addVideoFragment(){ // Perhaps, addStopPiont or sth, cause we decided to exclude VoidFragment idea

    }

    protected void setVideoInformation(){

    }
    @Override
    protected ArrayList <String> getPersonalInf(){
        ArrayList <String> info = new ArrayList<>();
        info = super.getPersonalInf();
        //info.add(group);
        info.add(role);
        // info.add(""+blockStatus);
       // Collections.addAll(info, listOfMarks.toString());
        return info;
    }

    protected void editVideoFragment(){ // the same story with the name

    }

    protected void editQuestion(){

    }

    protected void deleteQuestion(){

    }

    protected void addQuestion(){

    }

    protected void closeVideoFile(){

    }

    @Override
    protected void enterTheSystem(String login, String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
