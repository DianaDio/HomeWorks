/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SitvClasses;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import javax.swing.SwingUtilities;

import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;

/**
 *
 * @author Марина
 */
public class Main {
    
  public static Map<String, List<String>> userMap = new HashMap<>();
  public static Admin admin1;
  
  public static String checkLogin(String login){
      if (login.length()<3){
         return "Login should contain at least 3 symbols";}
      else if (userMap.containsKey(login)){
          return "This login is already exist";
      }
       else { 
         return "";
     }
  }
  
  public static String checkPassword(String password){
     if (password.length()<6){
         return "Password should contain at least 6 symbols";
     } 
     else if (password.contains(" ")){
         return "Password should not contain spaces";
     }
     else { 
         return "";
     }
  }
    
  public static String checkInfo(String info){
      if (info.equals("")){
          return "You should fill all fields";
      }
      else { 
         return "";
     }
  }
    
    
    static void marks() throws FileNotFoundException, IOException{
    	 String question = null;
		 String answer1 = null;
		 String answer2 = null;
		 String answer3 = null;
		 String rightAnswer = null;
		HSSFWorkbook myExcelBook = new HSSFWorkbook(new FileInputStream("WhyDoWeLove.xls"));
		  HSSFSheet myExcelSheet = myExcelBook.getSheet("list1");
		  //HSSFRow row = myExcelSheet.getRow(1);
		  int i=1;
		  ArrayList<Question> questionsList = new ArrayList<>();
		  HSSFRow row1 = myExcelSheet.getRow(i);
		  while (row1 != null) {
			  row1 = myExcelSheet.getRow(i);
			  if(row1.getCell(0).getCellType() == HSSFCell.CELL_TYPE_STRING){
		             question = row1.getCell(0).getStringCellValue();
		        }
			  if(row1.getCell(1).getCellType() == HSSFCell.CELL_TYPE_STRING){
		             answer1 = row1.getCell(1).getStringCellValue();
		        }
			  if(row1.getCell(2).getCellType() == HSSFCell.CELL_TYPE_STRING){
		             answer2 = row1.getCell(2).getStringCellValue();
		        }
			  if(row1.getCell(3).getCellType() == HSSFCell.CELL_TYPE_STRING){
		             answer3 = row1.getCell(3).getStringCellValue();
		        }
			  if(row1.getCell(4).getCellType() == HSSFCell.CELL_TYPE_STRING){
		             rightAnswer = row1.getCell(4).getStringCellValue();
		        }
			String q = question+"\n"+
		answer1+"\n"+answer2+"\n"+answer3;
			questionsList.add(new Question(q, rightAnswer)) ;
			 i++;
			 if  (myExcelSheet.getRow(i) == null)
			 {i--;
			 Question[] questions = {};
			 questions = questionsList.toArray(new Question[questionsList.size()]);
			 takeTest(questions);
			 break;}
		  }
		/*  if(row.getCell(0).getCellType() == HSSFCell.CELL_TYPE_STRING){
	             question = row.getCell(0).getStringCellValue();
	        }
		  if(row.getCell(1).getCellType() == HSSFCell.CELL_TYPE_STRING){
	             answer1 = row.getCell(1).getStringCellValue();
	        }
		  if(row.getCell(2).getCellType() == HSSFCell.CELL_TYPE_STRING){
	             answer2 = row.getCell(2).getStringCellValue();
	        }
		  if(row.getCell(3).getCellType() == HSSFCell.CELL_TYPE_STRING){
	             answer3 = row.getCell(3).getStringCellValue();
	        }
		  if(row.getCell(4).getCellType() == HSSFCell.CELL_TYPE_STRING){
	             rightAnswer = row.getCell(4).getStringCellValue();
	        }
		String q1 = question+"\n"+
	answer1+"\n"+answer2+"\n"+answer3;
		String q2 = "Who sliced all the people in two, because they angered the Gods?\n"+
	"a)Zeus\nb)Jupiter\nc)Pluto\n";
		Question [] questions = { new Question (q1, rightAnswer),
		new Question(q2,"a")
		};*/
		//takeTest(questions);
	}
	public static void takeTest(Question[] questions) {
		int mark = 0;
		Scanner keyboardInput = new Scanner(System.in);
		for (int j=0; j<questions.length; j++) {
			System.out.println(questions[j].promt);
			String answer = keyboardInput.nextLine();
			if (answer.equals(questions[j].answer)){
				mark++;
			}
		}
		System.out.println("You got "+mark+"/"+questions.length);
	}
        
        
        public static void exportFromExel() throws FileNotFoundException, IOException{
            //System.out.println("______________________");
            HSSFWorkbook myExcelBook = new HSSFWorkbook(new FileInputStream("usersInfo.xls"));
		  HSSFSheet myExcelSheet = myExcelBook.getSheet("usersInfo");
		  //HSSFRow row = myExcelSheet.getRow(1);
                   
                 for(int i = 0;i<=myExcelSheet.getLastRowNum();i++){
		 // System.out.println("______________________");
                    
		 // ArrayList<Question> questionsList = new ArrayList<>();
		 
              //  if (myExcelSheet.)
                    HSSFRow   row1 = myExcelSheet.getRow(i);
                 
		  
                      List <String> info = new ArrayList<>();
                      String key = null;
			  //row1 = myExcelSheet.getRow(i);
                            
			   
		             key = row1.getCell(0).getStringCellValue();
		        
                           for (int j=1; j<row1.getLastCellNum();j++){
			  //if(row1.getCell(j).getStringCellValue()!=null){
		             info.add(row1.getCell(j).getStringCellValue());
		 //       }
                 }
			   userMap.put(key, info);
                           //System.out.println(key);
                           //System.out.println(userMap);
                           
                          // i++;
        }
        }
        public static void importToExel() throws FileNotFoundException, IOException{
           /* try {
        FileWriter fstream1 = new FileWriter("usersInfo.xls");// конструктор с одним параметром - для перезаписи
        BufferedWriter out1 = new BufferedWriter(fstream1); //  создаём буферезированный поток
        out1.write(""); // очищаем, перезаписав поверх пустую строку
         out1.close(); // закрываем
         } catch (Exception e) 
            {System.err.println("Error in file cleaning: " + e.getMessage());}*/
            
            HSSFWorkbook book = new HSSFWorkbook(new FileInputStream("usersInfo.xls"));
          // book.removeSheetAt(0);
           // Workbook book = new HSSFWorkbook();
            Sheet sheet = book.getSheet("usersInfo");
           for (int i = 0; i<=sheet.getLastRowNum();i++){
           sheet.removeRow(sheet.getRow(i));}
           // sheet.
            Set<String> keyset = userMap.keySet();
        int rownum = 0;
        for (String key : keyset) {
             
            Row row = sheet.createRow(rownum++); 
             
            List<String> value = userMap.get(key);
            int cellnum = 0;
            Cell cell = row.createCell(cellnum++);
                 
              cell.setCellValue(key);
            for (Object obj : value) {
                // this line creates a cell in the next column of that row
                 cell = row.createCell(cellnum++);
                if (obj instanceof String)
                    cell.setCellValue((String)obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
            }
       FileOutputStream fos= new FileOutputStream("usersInfo.xls");
       
       book.write(fos);
       fos.close();}
           
           
           
           
           
           
          
        }
    public static void main(String[] args) throws IOException    {
    /* Workbook book = new HSSFWorkbook();
        Sheet sheet = book.createSheet("usersInfo");

    List <String> info = new ArrayList<>();
    info.add("123456");
    info.add("Maiden name");
    info.add("Ivanova");
    info.add("14/05/1990");
    info.add("Sidorova Svetlana");
    info.add("sveta1990@mail.ru");
   // info.add("-");
    //info.add("1");
           admin1 = new Admin("admin1", info);
          userMap.put("admin1",admin1.getPersonalInf());
           Set<String> keyset = userMap.keySet();
        int rownum = 0;
        for (String key : keyset) {
             
            Row row = sheet.createRow(rownum++); 
             
            List<String> value = userMap.get(key);
            int cellnum = 0;
            Cell cell = row.createCell(cellnum++);
                 
              cell.setCellValue(key);
            for (Object obj : value) {
                // this line creates a cell in the next column of that row
                 cell = row.createCell(cellnum++);
                if (obj instanceof String)
                    cell.setCellValue((String)obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
            }
       FileOutputStream fos= new FileOutputStream("usersInfo.xls");
       
       book.write(fos);
       fos.close();}*/
    //exportFromExel();
    exportFromExel();
       java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 
                
                    new EntryFrame().setVisible(true);
                
                 
            }
        });
        //importToExel();
           //File file = new File("C:\\Users\\Марина\\Desktop\\sitv.txt");
           
    //    FileOutputStream f2 = new FileOutputStream(file);
        //f.write("");
      //  ObjectOutputStream s2 = new ObjectOutputStream(f2);
        //s2.writeObject(userMap);
        //s2.close();
        //System.out.println(userMap);
    }

     
     
}
