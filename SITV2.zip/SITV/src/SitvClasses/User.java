/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SitvClasses;
//import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Марина
 */
public abstract class User {
     public
        String login; // String or StringBuilder what is better???
     String password;
        String birthdayDate; // Why type is not date???
        String secretQuestion;
        String secretAnswer;
        String role;
        String email;
        boolean blockStatus = false;//по дефолту пользователь не заблочен

    public String fio;

      // Here must be Constructor
    public User(String login, List <String> info){
         
        this.login = login;
         
        password = info.get(0);
        secretQuestion = info.get(1);
        secretAnswer = info.get(2);
        birthdayDate = info.get(3);
        fio = info.get(4);
        
        email = info.get(5);
       //group = info.get(6);
        
        //blockStatus = block;    
    }
    public User(String login, String password){
        this.login = login;
        this.password = password;
    }
/*private void setLogin(String login){
    this.login = login;
}*/
    /*protected void toRegister(){
         
    }*/

    protected abstract void enterTheSystem(String login, String password);
    /*private boolean correctInput(String login, String password){
        if (this.password.equals(password) && this.login.equals(login) ){
            return true;
        }
        else {
            return false;
        }
    }*/

    protected void watchVideo(){

    }

    protected void restoreAccess(){

    }

    protected ArrayList <String> getPersonalInf(){
        ArrayList <String> info = new ArrayList<>();
        //info.add(login);
        info.add(password);
        info.add(secretQuestion);
        info.add(secretAnswer);
        info.add(birthdayDate);
        info.add(fio);
         
        info.add(email);
         
         
return info;
    }

    protected void editPersonalInf(ArrayList <String> info) {//не знаю, пользователь может и одно поле захотеть отредактировать, и несколько
        login = info.get(0);
        password = info.get(1);
        secretQuestion = info.get(2);
        secretAnswer = info.get(3);
        birthdayDate = info.get(4);
        fio = info.get(5);
        
        //role = info.get(8);
        email = info.get(6);
        
    }
    

    protected void deleteProfile(){ 
 
    }

}
