/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SitvClasses;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Марина
 */
public class Student extends User {
     //protected
        //List<VideoFormat> or List<VideoTrack> watchedVideos

    public
        String group;
        List <Mark> listOfMarks;

    // Here must be Constructor
    public Student(String login, List <String> info){
        super(login, info);
        this.group = info.get(6);
        super.role = info.get(7);
        if ("true".equals(info.get(8))){
        this.blockStatus = true;
        }
        else {
            this.blockStatus = false;
        }
    }
     public Student(String login, String password){
        super(login, password);
    }

     

     

     

    protected void getWatchedVideos(){

    }

    protected List <Mark> getMarks(){
             return listOfMarks;
    }

    @Override
    protected void enterTheSystem(String login, String password) {//вообще не знаю, что тут писать
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public ArrayList <String> getPersonalInf(){
        ArrayList <String> info = new ArrayList<>();
        info = super.getPersonalInf();
        info.add(group);
        info.add(role);
         info.add(""+blockStatus);
       // Collections.addAll(info, listOfMarks.toString());
        return info;
    }
    @Override
     protected void editPersonalInf(ArrayList <String> info){
     super.editPersonalInf(info);
     group = info.get(7);
     }
}
