/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SitvClasses;

/**
 *
 * @author Марина
 */
public class Mark {
     int mark;
     int right;
             int wrong;
             float percent;
    public Mark(int right, int wrong, float percent, int mark){//просто мои фантазии
        this.mark = mark;
        this.right = right;
        this.wrong = wrong;
        this.percent = percent;
    }
    
     @Override
    public String toString() {
        return "Mark: "+mark+"Right answers: "+right+"Wrong answers: "+wrong+"Pencentage: "+percent;
    }
}
