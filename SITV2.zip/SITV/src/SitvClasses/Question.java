package SitvClasses;

public class Question {
    protected
        String level;

    public
        String question;
    	String promt;
    	String answer;
        //List<Answer> listOfAnswers;

    // Here must be Constructor
        public Question (String promt, String answer) {
        	this.promt = promt;
        	this.answer= answer;
        }

     protected void getQuestion(){

     }

}
