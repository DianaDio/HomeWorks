#include<iostream>


using namespace std;


int main()
{
	int N(0), K(0), i, temp;

	while(true)
	{
    cout << "Vvedite chislo: ";
    cin >> N;
    if((!cin) || (N<0))
    {
       cout << "ne verno vveli, povtorite vvod\n";
       cin.clear();
       while (cin.get() != '\n');
    }
    else break;
	}

	while(true)
	{
    cout << "Vvedite sdvig: ";
    cin >> K;
    if((!cin) || (K<0))
    {
       cout << "ne verno vveli, povtorite vvod\n";
       cin.clear();
       while (cin.get() != '\n');
    }
    else break;
	}


	int* a = new int[N];

	cout << "Zapolnite massiv" << endl;
	
	for (i = 0; i < N; i++) { cin >> a[i]; }


	while (K != 0) {
		temp = a[N - 1];
		for (i = N - 1; i != 0; i--) { a[i] = a[i - 1]; }
		a[0] = temp;
		K--;
	}

	for (i = 0; i < N; i++) {
		cout << a[i] << " ";
	}

	delete [] a;

	system("PAUSE");
	return 0;
}