#include<iostream>
#include<time.h>

using namespace std;

int main()
{
	srand(time(NULL));

	int N=rand()%10+1;

	int* a = new int [N];

	for (int i(0); i<N; i++) 
		{a[i]=rand()%20+1;
			cout << a[i] << " ";}

	cout << endl;

	int temp=0;     

	for (int i=1;  i<N; i++)
	{            
		for (int j=0;  j<N-i;  j++)
		{     
			if (a[j]>a[j+1])
			{temp=a[j];           
			a[j]=a[j+1];    
			a[j+1]=temp;}
		}
	}

	cout << "Sortirovka: " << endl;

	for (int i(0); i<N; i++) 
		{cout << a[i] << " ";}
		cout << endl;

	delete [] a;

	system ("PAUSE");
	return 0;
}