#include<iostream>
#include<time.h>

using namespace std;


int main()

{
	srand(time(NULL));

	int N = 0;
	while(true)
	{
    cout << "Vvedite chislo: ";
    cin >> N;
    if((!cin) || (N<0))
    {
       cout << "ne verno vveli, povtorite vvod\n";
       cin.clear();
       while (cin.get() != '\n');
    }
    else break;
	}

	int** A = new int*[N];

	for (int i(0); i < N; i++) A[i] = new int[N];

	for (int i(0); i < N; i++)
	{
		for (int j(0); j < N; j++) { A[i][j]= rand() %10+1 ; cout << A[i][j] << " "; }

		cout << endl;
	}

	cout << endl;

	for (int i(0); i < N; i++)
		for (int j(0); j < N; j++)
		{
			if (A[i][j] != A[j][i]) { cout << "Ne simmetrichnaya" << endl; goto point; }


		}
	
	cout << "Da, simmetrichnaya" << endl;





point: ;

	delete [] A;
	system("PAUSE");

	return 0;
}